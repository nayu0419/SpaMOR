"""
soFusion:
facilitating tissue compartmentalization via spatial multi-omics data fusion
"""